<?php
 
namespace App\Controllers;
 
use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UsuariosModel;
class Usuario extends Controller {
 
 
    public function index() {
         
        helper(['form', 'url']);
        $this->usuario_model = new UsuariosModel();
        $data['usuario'] = $this->usuario_model->get_all_usuario();
       //  echo json_encode( $data['usuario']);
        return view('usuario_view', $data);
    }
 
    public function usuario_add() {
 
        helper(['form', 'url']);
        $this->usuario_model = new UsuariosModel();
 
        $data = array(
            'Name' => $this->request->getPost('name'),
            'Email' => $this->request->getPost('email'),
            'Password' => $this->request->getPost('password'),
            'status' => 1,
        );
        $insert = $this->usuario_model->usuario_adds($data);
        echo json_encode(array("status" => 1));
    }
 
    public function ajax_edit($id) {
 
        $this->usuario_model = new UsuariosModel();
 
        $data = $this->usuario_model->get_by_id($id);
 
        echo json_encode($data);
    }
 
    public function usuario_update() {
 
        helper(['form', 'url']);
        $this->usuario_model = new UsuariosModel();

        $data = array(
           'Name' => $this->request->getPost('name'),
            'Email' => $this->request->getPost('email'),
            'Password' => $this->request->getPost('password'),
            'status' => 1,
        );
        $this->usuario_model->usuario_update(array('ID' => $this->request->getPost('ID')), $data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function usuario_delete($id) {
 
        helper(['form', 'url']);
        $this->usuario_model = new UsuariosModel();
        $this->usuario_model->delete_by_id($id);
        echo json_encode(array("status" => 1));
    }
 
}